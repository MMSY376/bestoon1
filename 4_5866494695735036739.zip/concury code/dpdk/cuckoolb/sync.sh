#!/usr/bin/env bash
cp -r ~Shouqian/project/* ../../